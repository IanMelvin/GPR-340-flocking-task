.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Examples
--------

rtfd-css.css
============

CSS defined in ``rtfd-css.css`` file:

.. admonition:: Examples on GitHub

  * Link to the example

.. admonition:: Stackoverflow

  * Link to the Stackoverflow

.. admonition:: CMake documentation

  * Link to the CMake documentation

.. admonition:: CMake mailing list

  * Link to discussion on CMake mailing list

.. admonition:: Wikipedia

  * Link to the Wikipedia article

custom.css
==========

Taken from: https://github.com/Microsoft/Office-Online-Test-Tools-and-Documentation

.. tip::

  This is a tip

.. warning::

  This is a warning

.. danger::

  This is dangerous!
