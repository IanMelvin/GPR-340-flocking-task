CSS for readthedocs.org
-----------------------

|build| |license|

.. |build| image:: https://readthedocs.org/projects/rtfd-css/badge/?version=latest
  :target: http://rtfd-css.readthedocs.io/en/latest/?badge=latest
  :alt: Documentation Status

.. |license| image:: https://img.shields.io/github/license/ruslo/rtfd-css.svg
  :target: https://github.com/ruslo/rtfd-css/blob/master/LICENSE
  :alt: LICENSE

* Sources: `<https://github.com/ruslo/rtfd-css>`_
* Documentation: `<http://rtfd-css.readthedocs.io>`_
* Reporting broken links, issues, general discussion: `<https://github.com/ruslo/rtfd-css/issues/new>`_
* Contacts: Ruslan Baratov <ruslan_baratov@yahoo.com>
