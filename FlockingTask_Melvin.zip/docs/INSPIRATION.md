- https://www.haroldserrano.com/blog/books-i-used-to-develop-a-game-engine
- https://gafferongames.com/
- https://www.redblobgames.com/
- https://research.ncl.ac.uk/game/mastersdegree/gametechnologies/previousinformation/
- https://www.toptal.com/game/video-game-physics-part-i-an-introduction-to-rigid-body-dynamics
- http://www.aortiz.me/2018/12/21/CG.html
- https://github.com/Angelo1211/SoftwareRenderer/wiki/Rendering-References
- https://fabiensanglard.net/duke3d/id%20as%20Super-Ego-%20The%20Creation%20of%20Duke%20Nukem%203D.pdf
- https://fabiensanglard.net/
- https://www.gamedesigning.org/learn/make-a-game-engine/
- http://twvideo01.ubm-us.net/o1/vault/gdc2015/presentations/Gyrling_Christian_Parallelizing_The_Naughty.pdf
- https://software.intel.com/content/www/us/en/develop/articles/designing-the-framework-of-a-parallel-game-engine.html
- https://learnopengl.com/
- https://github.com/id-Software
- https://www.gamasutra.com/blogs/MichaelKissner/20151027/257369/Writing_a_Game_Engine_from_Scratch__Part_1_Messaging.php
- https://fabiensanglard.net/duke3d/index.php
- https://github.com/Shervanator/Engine
- https://github.com/urho3d/Urho3D
- https://github.com/godotengine/godot
- https://github.com/OGRECave/ogre
- http://irrlicht.sourceforge.net/
- https://github.com/spring
- https://github.com/cocos2d/cocos2d-x
- https://github.com/MonoGame/MonoGame
- https://github.com/libgdx/libgdx
- https://github.com/CRYTEK/CRYENGINE
- https://openmw.org/en/
- http://www.horde3d.org/
- https://www.unrealengine.com/en-US/eula
- https://github.com/EpicGames/UnrealEngine

- https://unity3d.com/

Uses the following 3rd party libraries:
- SDL2 window library.
- stb_image.h image library.
- OpenGL 3 / OpenGL ES 2.0 / OpenGL ES 3.0 Graphics APIs.
- Assimp asset importing library.
- GLEW extension loading library.
- Dear ImGui UI library.

Docs:
- https://medium.com/@kevinkreuzer/the-way-to-fully-automated-releases-in-open-source-projects-44c015f38fd6?_branch_match_id=467041473575681523
